// evenOddNumbersLL.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ROW_SIZE 2048 

struct node
{
    int data;
    struct node* next;
};


// Function to insert a node in an ordered list
struct node* insertInAscendingOrder(struct node* head, struct node* newNode) {
    // If the list is empty or the new node should be inserted at the beginning
    if (head == NULL || newNode->data < head->data) {
        newNode->next = head;
        return newNode;
    }
    // Traverse the list to find the correct position for the new node
    struct node* current = head;
    while (current->next != NULL && current->next->data < newNode->data) {
        current = current->next;
    }
    // Insert the new node in the correct position
    newNode->next = current->next;
    current->next = newNode;
    return head;
}


// Function to insert a node in an ordered list
struct node* insertInDescendingOrder(struct node* head, struct node* newNode) {
    // If the list is empty or the new node should be inserted at the beginning
    if (head == NULL || newNode->data > head->data) {
        newNode->next = head;
        return newNode;
    }
    // Traverse the list to find the correct position for the new node
    struct node* current = head;
    while (current->next != NULL && current->next->data > newNode->data) {
        current = current->next;
    }
    // Insert the new node in the correct position
    newNode->next = current->next;
    current->next = newNode;
    return head;
}


// Function to create a new node
struct node* createNode(int value) {
    struct node* newNode = (struct node*)malloc(sizeof(struct node));
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
    }
    else {
        newNode->data = value;
        newNode->next = NULL;
    }
    return newNode;
}


// Function to print the elements of the list
void printList(struct node* head) {
    struct node* current = head;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}


int main(int argc, char* argv[])
{
    struct node *oddNum, *evenNum, *newNode;
    char row[MAX_ROW_SIZE];
    int element;
    int numElements = 0;

    evenNum = NULL;
    oddNum = NULL;
    // check how many arguments are passed
    if (argc != 2)
    {
        printf("Error: usage %s integers_filename\n", argv[0]);
        return(1);
    }
    FILE* fi = fopen(argv[1], "r");
    if (fi == NULL)
    {
        perror("Error opening input file\n");
        return(2);
    }
    while (!feof(fi))
    {
        if (fgets(row, MAX_ROW_SIZE - 1, fi) != row)
        {
            if (feof(fi))
            {
                break;
            }
            else
            {
                perror("Error reading file input");
                return(3);
            }
        }
        char* t;
        if ((t = strtok(row, " ")) == NULL)
        {
            perror("Error reading numbers from file");
            return(4);
        }
        do
        {
            element = atoi(t);
            if (element == 0)
            {
                break;
            }
            newNode = createNode(element);
            if (newNode == NULL)
            {
                perror("Error allocating memory for numbers from file");
                return(5);
            }
            //printf("%d\t", element);
            if (element % 2 == 0)
            {
                evenNum = insertInAscendingOrder(evenNum, newNode);
            }
            else
            {
                oddNum = insertInDescendingOrder(oddNum, newNode);
            }
        } while ((t = strtok(NULL, " ")) != NULL);
    }

    //print the number of arguments passed to the the program 
    printf("\nNumbers list of %d elements\n", numElements);
    // print the ordered list
    printf("Even numbers ordered list of elements:\t");
    printList(evenNum);
    printf("\n");
    printf("Odd numbers ordered list of elements:\t");
    printList(oddNum);
    printf("\n");
    exit(0);
}
