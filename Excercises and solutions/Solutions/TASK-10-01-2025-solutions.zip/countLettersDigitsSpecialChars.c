// countLettersDigitsSpecialChars.c

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define str_size 100 // Declare the maximum size of the string

int main(int argc, char *argv[]) {
    int alp, digit, splch; // Declare variables for alphabets, digits, special characters
    alp = digit = splch = 0; // Initialize counters to zero

    printf("\n\nCount total number of alphabets, digits, and special characters :\n"); // Display information about the task
    printf("--------------------------------------------------------------------\n");
    if (argc != 2)
    {
        printf("Error: usage %s filename_to_read\n", argv[0]);
        return(1);
    }

    printf("File to be read:\n%s\n", argv[1]);
    FILE* fp = fopen(argv[1], "rb");
    if (fp == NULL)
    {
        perror("Error opening input file\n");
        return(2);
    }
    int uc = fgetc(fp);
    while (uc != EOF)
    {
        if ((uc >= 'a' && uc <= 'z') || (uc >= 'A' && uc <= 'Z')) {
            alp++; // Increment the alphabet count if the character is an alphabet
        }
        else
        {
            if ((uc >= '0' && uc <= '9') ) {
                digit++; // Increment the digit count if the character is a digit
            }
            else {
                splch++; // Increment the special character count for all other characters
            }
        }
        uc = fgetc(fp);
    }

    // Display the counts of alphabets, digits, and special characters in the string
    printf("Number of Alphabets in the string is : %d\n", alp);
    printf("Number of Digits in the string is : %d\n", digit);
    printf("Number of Special characters in the string is : %d\n\n", splch);

    return 0; // Return 0 to indicate successful execution of the program
}
