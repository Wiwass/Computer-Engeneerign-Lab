#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>
#include <errno.h>

//#define PORT 8888
#define PORT "8888"
//#define SERVER_IP "127.0.0.1"

int main (int argc, char *argv[1])
{
	int cliSoc ;
	struct sockaddr_in serverAddr;
	struct addrinfo *result = NULL, *ptr = NULL, hints;
	char buffer [1024];

	if (argc != 2)
	{
		printf("Usage %s server-name\n", argv[0]);
		return(1);
	}

	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	int iResult = getaddrinfo(argv[1], PORT, &hints, &result);
	if (iResult != 0)
	{
		printf("getaddrinfo failed with error: %d\n", iResult);
		return(1);
	}

	// Attempt to connect to an address until one succeeds
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
	{
		// Create a SOCKET for connecting to server
		cliSoc = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
		if (cliSoc == -1)
		{
			printf("socket creation failed with error: %ld\n", errno);
			return(1);
		}

		// Connect to server.
		iResult = connect(cliSoc, ptr->ai_addr, (int)ptr->ai_addrlen);
		if (iResult == -1)
		{
			close(cliSoc);
			cliSoc = -1;
			continue;
		}
		break;
	}

	freeaddrinfo(result);

	if (cliSoc == -1)
	{
		printf("Unable to connect to server!\n");
		return(1);
	}
/*
	// Create client socket
cliSoc  = socket (AF_INET, SOCK_STREAM, 0);
if (cliSoc  < 0) {
perror ("Error in socket creation");
exit (1);
}

printf("Client %d socket created.\n", getpid ());

// Set server address parameters
serverAddr.sin_family = AF_INET;
serverAddr.sin_port = htons (PORT);
serverAddr.sin_addr.s_addr = inet_addr (SERVER_IP);
// Connect to the server
if (connect (cliSoc , (struct sockaddr*) & serverAddr, sizeof (serverAddr)) < 0) {
perror("Error in connecting to server");
exit (1);
}
*/
	printf ("Connected to server.\n");
	while (1)
	{
		// Read input from user
		printf ("Client %d - Enter a message: ", getpid());
		fgets (buffer, sizeof(buffer), stdin);
 
		if (send (cliSoc, buffer, strlen (buffer), 0) < 0)
		{
			perror ("Error in sending data");
			return(1);

		}
		// Receive response from the server
		memset (buffer, 0, sizeof(buffer));
		if (recv(cliSoc, buffer, sizeof (buffer), 0) < 0)
		{
			perror ("Error in receiving data");
			return(1);
		}
		printf ("Client %d - Server response: %s\n", getpid(), buffer);
		if (strncmp(buffer, "SHUTDOWN", strlen("SHUTDOWN")) == 0 )
			break;
	}

	// Close the client socket
	close (cliSoc);
	return(0);
}
