// Client side C program to demonstrate Socket programming
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#define PORT "8080"

int main(int argc, char const* argv[])
{
	int status, valread, client_fd;
	struct sockaddr_in serv_addr;
	struct addrinfo *result = NULL, *ptr = NULL, hints;
	char* hello = "Hello from client";
	char buffer[1024] = { 0 };
	if (argc != 2)
	{
		printf("Usage %s server-name\n", argv[0]);
		return(1);
	}
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	int iResult = getaddrinfo(argv[1], PORT, &hints, &result);
	if (iResult != 0)
	{
		printf("getaddrinfo failed with error: %d\n", iResult);
		return(1);
	}
	// Attempt to connect to an address until one succeeds
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
	{

		// Create a SOCKET for connecting to server
		client_fd = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
		if (client_fd == -1)
		{
			printf("socket creation failed with error: %ld\n", errno);
			return(1);
		}

		// Connect to server.
		iResult = connect(client_fd, ptr->ai_addr, (int)ptr->ai_addrlen);
		if (iResult == -1)
		{
			close(client_fd);
			client_fd = -1;
			continue;
		}
		break;
	}

	freeaddrinfo(result);

	if (client_fd == -1)
	{
		printf("Unable to connect to server!\n");
		return(1);
	}
/*
	if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("\n Socket creation error \n");
		return -1;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(PORT);

	// Convert IPv4 and IPv6 addresses from text to binary
	// form
	if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)
		<= 0) {
		printf(
			"\nInvalid address/ Address not supported \n");
		return -1;
	}

	if ((status
		= connect(client_fd, (struct sockaddr*)&serv_addr,
				sizeof(serv_addr)))
		< 0) {
		printf("\nConnection Failed \n");
		return -1;
	}
*/
	send(client_fd, hello, strlen(hello), 0);
	printf("Hello message sent\n");
	valread = read(client_fd, buffer, 1024 - 1); // subtract 1 for the null terminator at the end
	printf("%s\n", buffer);

	// closing the connected socket
	close(client_fd);
	return 0;
}

