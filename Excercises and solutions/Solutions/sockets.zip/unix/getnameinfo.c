#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

int main() {
    struct sockaddr_in sa;
    char host[NI_MAXHOST];
    char service[NI_MAXSERV];

    // Step 1: Set up a sample IPv4 socket address
    sa.sin_family = AF_INET;
    sa.sin_port = htons(8080);               // Port 8080
    inet_pton(AF_INET, "75.2.126.117", &sa.sin_addr);

    // Step 2: Call getnameinfo to resolve the address
    int status = getnameinfo((struct sockaddr *)&sa, sizeof(sa),
                             host, sizeof(host),
                             service, sizeof(service),
                             NI_NUMERICHOST | NI_NUMERICSERV);

    if (status != 0) {
        fprintf(stderr, "getnameinfo: %s\n", gai_strerror(status));
        return 1;
    }

    // Step 3: Print the results
    printf("Host: %s\n", host);
    printf("Service: %s\n", service);

    return 0;
}
