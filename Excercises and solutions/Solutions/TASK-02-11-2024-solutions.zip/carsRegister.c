// carsRegister.c 
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_NAME 21
#define MAX_CARS 30
#define MAX_PLATE 11
#define MAX_LINE 81

struct carRegister
{
	char carName[MAX_NAME + 1];
	char carPlate[MAX_PLATE + 1];
	int regYear;
	int power;
};
struct carRegister carsShop[MAX_CARS];

int main(int argc, char *argv[])
{
	char s[MAX_LINE];
	int numCar = 0;
	if (argc != 2)
	{
		printf("Bad arguments: usage %s filename_to_be_read\n", argv[0]);
		return(1);
	}
	FILE* fr = fopen(argv[1], "r");
	if (fr == NULL)
	{
		perror("error opening file passed as argument\n");
		return(2);
	}

	while (!feof(fr))
	{
		if (fgets(s, MAX_LINE, fr) != s)
		{
			if (feof(fr))
			{
				break;
			}
			else
			{
				printf("Error reading file input");
				return(3);
			}
		}
		//printf("%s\n", s);
		char* t;
		if ((t = strtok(s, " ")) != NULL)
		{
			strcpy(carsShop[numCar].carName, t);
			if ((t = strtok(NULL, " ")) != NULL)
			{
				strcpy(carsShop[numCar].carPlate, t);
			}
			if ((t = strtok(NULL, " ")) != NULL)
			{
				carsShop[numCar].regYear = atoi(t);
			}
			if ((t = strtok(NULL, " ")) != NULL)
			{
				carsShop[numCar].power = atoi(t);
			}
			numCar++;
		}
		else
		{
			perror("Error reading tokens from row");
			return(4);
		}
	}
	float averagePower = 0.0;
	int mRecent = 0, imRecent = 0;
	int lRecent = INT_MAX, ilRecent = 0;
	int mPowerful = 0, imPowerful = 0;
	int lPowerful = INT_MAX, ilPowerful = 0;

	for (int i = 0; i < numCar; i++)
	{
		printf("%s %s %d %d\n", carsShop[i].carName, carsShop[i].carPlate,
			carsShop[i].regYear, carsShop[i].power);
		averagePower += carsShop[i].power;
		if (carsShop[i].power > mPowerful)
		{
			mPowerful = carsShop[i].power;
			imPowerful = i;
		}
		if (carsShop[i].power < lPowerful)
		{
			lPowerful = carsShop[i].power;
			ilPowerful = i;
		}
		if (carsShop[i].regYear > mRecent)
		{
			mRecent = carsShop[i].regYear;
			imRecent = i;
		}
		if (carsShop[i].regYear < lRecent)
		{
			lRecent = carsShop[i].regYear;
			ilRecent = i;
		}
	}
	printf("Power average is %f\n", averagePower / numCar);
	printf("The most powerful car is %s %s %d %d\n", carsShop[imPowerful].carName, carsShop[imPowerful].carPlate,
		carsShop[imPowerful].regYear, carsShop[imPowerful].power);
	printf("The least powerful car is %s %s %d %d\n", carsShop[ilPowerful].carName, carsShop[ilPowerful].carPlate,
		carsShop[ilPowerful].regYear, carsShop[ilPowerful].power);
	printf("The most recent car is %s %s %d %d\n", carsShop[imRecent].carName, carsShop[imRecent].carPlate,
		carsShop[imRecent].regYear, carsShop[imRecent].power);
	printf("The least recent car is %s %s %d %d\n", carsShop[ilRecent].carName, carsShop[ilRecent].carPlate,
		carsShop[ilRecent].regYear, carsShop[ilRecent].power);
	exit(0);
}
