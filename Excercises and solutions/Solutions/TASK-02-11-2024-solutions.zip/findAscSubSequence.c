// findAscSubSequence.c 
//
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
#define MAX_A_SIZE 50 // size of the array where entered decimal values will be managed
	int num[MAX_A_SIZE];
	int val, counter = 0, total = 0;
	int i = 0, f = 0, maxL = 0;
	int initial = 0, final = 0;
	if (argc != 2)
	{
		printf("Bad arguments: usage %s filename_to_be_read\n", argv[0]);
		return(1);
	}
	FILE* fr = fopen(argv[1], "r");
	if (fr == NULL)
	{
		perror("error opening file passed as argument\n");
		return(2);
	}

	do
	{
		if (fscanf(fr, "%d", &val) != 1)
		{
			perror("Error reading integer value");
			return(3);
		}
		if (val > 0)
		{
			num[total] = val;
			if (total == 0)
			{
				counter++;
				total++;
			}
			else
			{
				if (num[total] > num[total-1])
				{
					counter++;
					f++;
					total++;
				}
				else
				{
					if (maxL < counter)
					{
						maxL = counter;
						initial = i;
						final = f;
						i = total;
						f = total;
						counter = 1;
						total++;
					}
					else
					{
						i = total;
						f = total;
						counter = 1;
						total++;
					}
				}
			}
		}
		else if (val == 0)
		{
			if (maxL < counter)
			{
				maxL = counter;
				initial = i;
				final = f;
			}
		}
		else
		{
			printf("Error negative value %d discarded\n", val);
		}
	} while (val != 0);
	printf("Maximum ascending subsequence lenght is %d\n", maxL);
	printf("initial = %d\tfinal = %d\n", initial, final);
	printf("Printing subsequence %d", num[initial]);
	for (int i = initial+1; i <= final; i++)
	{
		printf(", %d",num[i]);
	}
	printf("\n\n");
	return 0;
}
